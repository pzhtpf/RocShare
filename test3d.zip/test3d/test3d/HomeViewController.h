//
//  HomeViewController.h
//  test3d
//
//  Created by tianpengfei on 16/8/7.
//  Copyright © 2016年 tianpengfei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SceneKit/SceneKit.h>

@interface HomeViewController : UIViewController

@property(strong,nonatomic)SCNView *scnView;

@end
